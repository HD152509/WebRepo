/**
 * 
 */

	function toHome() {

	alert('메인화면으로 이동합니다.');
	location.href = 'suchan_blog.html';
}
